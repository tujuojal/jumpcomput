function V=vauhti2(v0,p)
[D,g,m,myy,alastulo,nokka,alfa]=param;
                                  
B=(sin(alfa)*g-cos(alfa)*g*myy);    
A=1/m*D;
%t=(0:1:20);
%pitaisi etsia se t jolla ollaan tietyssa paikassa p
%(kuljettu matka p metria rinteen pintaa pitkin)? 
T=fzero(@(t) real((-1/2/A*log(tanh(t*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))-1)-1/2/A*log(tanh(t*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))+1)-(-1/2/A*log(tanh(0*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))-1)-1/2/A*log(tanh(0*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))+1))-p)),100);   %integroitu v=tanh(t*(B*A)^(1/2)+atanh(A*a/(B*A)^(1/2)))*(B*A)^(1/2)/A
%v=tanh(t.*(B*A)^(1/2)+atanh(A*v0/(A*B)^(1/2)))*(A*B)^(1/2)/A;       %V ratkaistu dv/dt=B-A*v^2
V=real(tanh(T*(B*A)^(1/2)+atanh(A*v0/(A*B)^(1/2)))*(A*B)^(1/2)/A);

%hold on;
%plot(t,v);
%p=(-1/2/A*log(tanh(t.*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))-1)-1/2/A*log(tanh(t.*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))+1)-(-1/2/A*log(tanh(0*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))-1)-1/2/A*log(tanh(0*(B*A)^(1/2)+atanh(A*v0/(B*A)^(1/2)))+1))-p);

%plot(t,p,'c');