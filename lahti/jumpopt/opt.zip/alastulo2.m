function alastulo2(vauhti,kulma)
%antaa ulos alastulon pudotuksen hyppyrin tasalta kun
%tiedetaan nopeus nokalla ja hyppyrin kulma
YA=